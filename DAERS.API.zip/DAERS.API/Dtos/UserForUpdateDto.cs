namespace DAERS.API.Dtos
{
    public class UserForUpdateDto
    {
        public string Introduction { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public float Height { get; set; }
        public float Weight { get; set; }
        public float Lats { get; set; }
        public float Waist { get; set; }
        
    }
}